class MinimaxAgent:
    def __init__(self, depth=4):
        self.depth = depth

    def evaluate_board(self, game, my_color):
        enemy_color = -my_color
        
        # چک کردن اینکه بازی تموم شده یا نه
        if game.game_over():
            black_score, white_score = game.score()
            my_score = black_score if my_color == 1 else white_score
            enemy_score = white_score if my_color == 1 else black_score
            
            # دادن یه عدد خیلی بزرگ برای برد و خیلی کوچیک برای باخت
            if my_score > enemy_score:
                return 999999
            elif my_score < enemy_score:
                return -999999
            return 0

        # معیار اول: اختلاف مهره‌ها
        black_score, white_score = game.score()
        my_score = black_score if my_color == 1 else white_score
        enemy_score = white_score if my_color == 1 else black_score
        coin_diff = 100 * (my_score - enemy_score) / (my_score + enemy_score + 1)

        # معیار دوم: تعداد حرکات مجاز ما نسبت به حریف (تحرک‌پذیری)
        my_moves = len(game.get_valid_moves(my_color))
        enemy_moves = len(game.get_valid_moves(enemy_color))
        mobility_score = 0
        if (my_moves + enemy_moves) > 0:
            mobility_score = 100 * (my_moves - enemy_moves) / (my_moves + enemy_moves)

        # معیار سوم: گرفتن گوشه‌های صفحه که امتیاز بالایی داره
        corners = [(0, 0), (0, game.size - 1), (game.size - 1, 0), (game.size - 1, game.size - 1)]
        my_corners = 0
        enemy_corners = 0
        
        # با یه حلقه ساده چک میکنیم گوشه‌ها دست کیه
        for r, c in corners:
            if game.board[r][c] == my_color:
                my_corners += 1
            elif game.board[r][c] == enemy_color:
                enemy_corners += 1
                
        corner_score = 0
        if (my_corners + enemy_corners) > 0:
            corner_score = 100 * (my_corners - enemy_corners) / (my_corners + enemy_corners)

        # جمع بندی امتیازات با وزن‌های مشخص شده
        return coin_diff + (2.5 * mobility_score) + (15.0 * corner_score)

    def run_minimax(self, game, current_depth, is_my_turn, my_color):
        # اگه به انتهای عمق رسیدیم یا بازی تموم شد، امتیاز صفحه رو برمی‌گردونیم
        if current_depth == 0 or game.game_over():
            return self.evaluate_board(game, my_color), None

        # پیدا کردن اینکه الان نوبت کیه
        current_player = my_color if is_my_turn else -my_color
        valid_moves = game.get_valid_moves(current_player)

        # قانون پاس دادن تو اتلو: اگه بازیکنی حرکت نداشت نوبتش میپره
        if len(valid_moves) == 0:
            score, _ = self.run_minimax(game, current_depth - 1, not is_my_turn, my_color)
            return score, None

        if is_my_turn:
            best_score = float('-inf')
            best_move = None
            for move in valid_moves:
                new_game = game.copy()
                new_game.make_move(current_player, move[0], move[1])
                score, _ = self.run_minimax(new_game, current_depth - 1, False, my_color)
                
                # پیدا کردن ماکزیمم امتیاز
                if score > best_score:
                    best_score = score
                    best_move = move
            return best_score, best_move
            
        else:
            best_score = float('inf')
            best_move = None
            for move in valid_moves:
                new_game = game.copy()
                new_game.make_move(current_player, move[0], move[1])
                score, _ = self.run_minimax(new_game, current_depth - 1, True, my_color)
                
                # پیدا کردن مینیمم امتیاز
                if score < best_score:
                    best_score = score
                    best_move = move
            return best_score, best_move

    def choose_move(self, game, player):
        # شروع حرکت با فراخوانی تابع مینی‌مکس
        score, move = self.run_minimax(game, self.depth, True, player)
        return move