class AlphaBetaAgent:
    def __init__(self, depth=4):
        self.depth = depth

    def evaluate_board(self, game, my_color):
        enemy_color = -my_color
        
        # اگه بازی تموم شده باشه، یه امتیاز خیلی بزرگ یا خیلی کوچیک برمی‌گردونیم
        if game.game_over():
            black_score, white_score = game.score()
            my_score = black_score if my_color == 1 else white_score
            enemy_score = white_score if my_color == 1 else black_score
            
            if my_score > enemy_score:
                return 999999
            elif my_score < enemy_score:
                return -999999
            return 0

        # معیار اول: اختلاف تعداد مهره‌های ما و حریف
        black_score, white_score = game.score()
        my_score = black_score if my_color == 1 else white_score
        enemy_score = white_score if my_color == 1 else black_score
        coin_diff = 100 * (my_score - enemy_score) / (my_score + enemy_score + 1)

        # معیار دوم: تعداد حرکت‌های مجاز برای ما در مقابل حریف (Mobility)
        my_moves = len(game.get_valid_moves(my_color))
        enemy_moves = len(game.get_valid_moves(enemy_color))
        mobility_score = 0
        if (my_moves + enemy_moves) > 0:
            mobility_score = 100 * (my_moves - enemy_moves) / (my_moves + enemy_moves)

        # معیار سوم: گرفتن گوشه‌های زمین که تو اتلو خیلی مهمه
        corners = [(0, 0), (0, game.size - 1), (game.size - 1, 0), (game.size - 1, game.size - 1)]
        my_corners = 0
        enemy_corners = 0
        
        for r, c in corners:
            if game.board[r][c] == my_color:
                my_corners += 1
            elif game.board[r][c] == enemy_color:
                enemy_corners += 1
                
        corner_score = 0
        if (my_corners + enemy_corners) > 0:
            corner_score = 100 * (my_corners - enemy_corners) / (my_corners + enemy_corners)

        # ترکیب این سه تا معیار با وزن‌های مختلف (گوشه‌ها بیشترین وزن رو دارن)
        return coin_diff + (2.5 * mobility_score) + (15.0 * corner_score)

    def run_alphabeta(self, game, current_depth, alpha, beta, is_my_turn, my_color):
        # رسیدن به انتهای عمق تعیین شده یا تموم شدن بازی
        if current_depth == 0 or game.game_over():
            return self.evaluate_board(game, my_color), None

        current_player = my_color if is_my_turn else -my_color
        valid_moves = game.get_valid_moves(current_player)

        # قانون پاس دادن: اگه بازیکنی حرکت مجازی نداشت، نوبتش می‌پره
        if len(valid_moves) == 0:
            score, _ = self.run_alphabeta(game, current_depth - 1, alpha, beta, not is_my_turn, my_color)
            return score, None

        if is_my_turn:
            best_score = float('-inf')
            best_move = None
            for move in valid_moves:
                new_game = game.copy()
                new_game.make_move(current_player, move[0], move[1])
                
                score, _ = self.run_alphabeta(new_game, current_depth - 1, alpha, beta, False, my_color)
                
                if score > best_score:
                    best_score = score
                    best_move = move
                    
                alpha = max(alpha, best_score)
                if beta <= alpha:
                    break  # هرس کردن شاخه
            return best_score, best_move
            
        else:
            best_score = float('inf')
            best_move = None
            for move in valid_moves:
                new_game = game.copy()
                new_game.make_move(current_player, move[0], move[1])
                
                score, _ = self.run_alphabeta(new_game, current_depth - 1, alpha, beta, True, my_color)
                
                if score < best_score:
                    best_score = score
                    best_move = move
                    
                beta = min(beta, best_score)
                if beta <= alpha:
                    break  # هرس کردن شاخه
            return best_score, best_move

    def choose_move(self, game, player):
        # شروع الگوریتم با مقادیر اولیه آلفا و بتا
        score, move = self.run_alphabeta(game, self.depth, float('-inf'), float('inf'), True, player)
        return move
    
    