"""
University: University of Isfahan
Faculty: Mathematics and Statistics
Department: Computer Science
Course: Artificial Intelligence
Professor: Dr. Faria Nasiri Mofakham
TAs: MehrAzin Marzough, Mohammad Karimi, Anahita Honarmandian
Project: Adversarial Search in Othello (Minimax and Alpha-Beta Pruning)
"""
from game.othello import Othello, BLACK, WHITE
from tournament import play_game
from agents.random_agent import RandomAgent
from agents.greedy_agent import GreedyAgent
from agents.minimax_agent import MinimaxAgent
from agents.alphabeta_agent import AlphaBetaAgent

def test_agents(agent1, agent2, num_games=20):
    # متغیرها برای نگه داشتن تعداد برد و باخت و مساوی
    agent1_wins = 0
    agent2_wins = 0
    draws = 0

    for i in range(num_games):
        # برای اینکه عادلانه باشه، جای مهره سیاه و سفید رو تو بازی‌های زوج و فرد عوض می‌کنیم
        if i % 2 == 0:
            score = play_game(agent1, agent2)
            score1 = score[0]
            score2 = score[1]
        else:
            score = play_game(agent2, agent1)
            # چون جای بازیکن‌ها عوض شده، امتیازها رو هم برعکس می‌خونیم
            score2 = score[0]
            score1 = score[1]

        # چک می‌کنیم کی برده
        if score1 > score2:
            agent1_wins += 1
        elif score1 < score2:
            agent2_wins += 1
        else:
            draws += 1

    # حساب کردن درصد برد عامل اول
    win_rate = (agent1_wins / num_games) * 100
    
    print(f"Total Games: {num_games}")
    print(f"Agent 1 Wins: {agent1_wins}")
    print(f"Agent 2 Wins: {agent2_wins}")
    print(f"Draws: {draws}")
    print(f"Agent 1 Win Rate: {win_rate}%")
    print("-" * 40)
    
    return win_rate

if __name__ == "__main__":
    # ساختن عامل‌ها
    minimax_player = MinimaxAgent(depth=3)
    alphabeta_player = AlphaBetaAgent(depth=4)
    random_player = RandomAgent()
    greedy_player = GreedyAgent()

    print("Test 1: Minimax vs Random")
    test_agents(minimax_player, random_player, num_games=20)

    print("Test 2: AlphaBeta vs Random")
    test_agents(alphabeta_player, random_player, num_games=20)

    print("Test 3: Minimax vs Greedy")
    test_agents(minimax_player, greedy_player, num_games=20)

    print("Test 4: AlphaBeta vs Greedy")
    test_agents(alphabeta_player, greedy_player, num_games=20)
    
    print("Test 5: AlphaBeta vs Minimax (Head-to-Head)")
    test_agents(alphabeta_player, minimax_player, num_games=20)
    

    